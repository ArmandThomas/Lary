import { createStore } from 'redux'
import reducerProfil from './Reducers/profil'

export default createStore(reducerProfil)
